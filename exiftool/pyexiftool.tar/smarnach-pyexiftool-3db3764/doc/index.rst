.. PyExifTool documentation master file, created by
   sphinx-quickstart on Thu Apr 12 17:42:54 2012.

PyExifTool -- A Python wrapper for Phil Harvey's  ExifTool
==========================================================

.. automodule:: exiftool
   :members:
